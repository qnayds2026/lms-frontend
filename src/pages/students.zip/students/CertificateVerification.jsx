import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import {
  Award,
  BookOpen,
  Briefcase,
  CalendarDays,
  CheckCircle2,
  GraduationCap,
  Loader2,
  Search,
  ShieldCheck,
  Video,
  XCircle,
} from "lucide-react";
import api from "../../api/axios";

// Certificate type display meta. Matches the types the backend can issue:
// Course, Webinar, Internship, Workshop. Falls back gracefully if the
// verification response doesn't include a `type` field or uses a value
// not listed here.
const TYPE_META = {
  COURSE: { label: "Course", icon: BookOpen },
  WEBINAR: { label: "Webinar", icon: Video },
  INTERNSHIP: { label: "Internship", icon: Briefcase },
  WORKSHOP: { label: "Workshop", icon: GraduationCap },
};

function getTypeMeta(type) {
  const key = (type || "").toString().toUpperCase();
  return TYPE_META[key] || { label: "Course", icon: BookOpen };
}

const CertificateVerification = () => {
  const { verificationCode } = useParams();
  const navigate = useNavigate();

  // Controlled input for the "enter a code" form, shown when no code is
  // present in the URL.
  const [codeInput, setCodeInput] = useState("");

  const [certificate, setCertificate] = useState(null);
  const [valid, setValid] = useState(false);
  const [loading, setLoading] = useState(!!verificationCode);
  const [error, setError] = useState("");
  const [checked, setChecked] = useState(false); // has a verification attempt run yet

  useEffect(() => {
    if (!verificationCode) {
      // No code in the URL: show the entry form instead of an API call.
      setLoading(false);
      setChecked(false);
      setCertificate(null);
      setValid(false);
      setError("");
      return;
    }

    let cancelled = false;

    const verifyCertificate = async () => {
      try {
        setLoading(true);
        setError("");

        const res = await api.get(`/certificates/verify/${verificationCode}`);
        const raw = res.data;

        if (cancelled) return;

        setValid(raw?.valid === true);
        setCertificate(raw?.data || null);
      } catch (err) {
        if (cancelled) return;

        console.error("Certificate verification failed:", err);

        setValid(false);
        setCertificate(null);
        setError(
          err?.response?.data?.message ||
            "This certificate could not be verified.",
        );
      } finally {
        if (!cancelled) {
          setLoading(false);
          setChecked(true);
        }
      }
    };

    verifyCertificate();

    return () => {
      cancelled = true;
    };
  }, [verificationCode]);

  const formatDate = (date) => {
    if (!date) return "—";

    return new Date(date).toLocaleDateString("en-IN", {
      day: "2-digit",
      month: "long",
      year: "numeric",
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const code = codeInput.trim();
    if (!code || loading) return; // prevent duplicate/empty submits

    navigate(`/verify-certificate/${encodeURIComponent(code)}`);
  };

  // ==========================
  // ENTRY FORM (no code in the URL yet)
  // ==========================

  if (!verificationCode) {
    return (
      <div className="min-h-screen bg-slate-50 px-4 py-10 md:px-8">
        <div className="mx-auto max-w-xl">
          <div className="text-center">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-sky-50">
              <Award className="h-8 w-8 text-sky-600" />
            </div>

            <p className="mt-5 text-xs font-semibold uppercase tracking-[0.3em] text-sky-600">
              QNAYDS ACADEMY
            </p>

            <h1 className="mt-3 text-3xl font-bold tracking-tight text-slate-900 md:text-4xl">
              Certificate Verification
            </h1>

            <p className="mx-auto mt-3 max-w-md text-sm leading-6 text-slate-500">
              Enter a certificate verification code to check whether it was
              issued by QNAYDS Academy.
            </p>
          </div>

          <form
            onSubmit={handleSubmit}
            className="mt-8 rounded-3xl border border-slate-200 bg-white p-6 shadow-xl shadow-slate-200/50 md:p-8"
          >
            <label
              htmlFor="verification-code"
              className="text-xs font-semibold uppercase tracking-wider text-slate-400"
            >
              Verification Code
            </label>

            <div className="relative mt-2">
              <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <input
                id="verification-code"
                type="text"
                value={codeInput}
                onChange={(e) => setCodeInput(e.target.value)}
                placeholder="e.g. a73504ad2be8a5d78a2904a31cf2c840"
                className="w-full rounded-xl border border-slate-200 bg-slate-50 py-3 pl-11 pr-4 text-sm text-slate-900 outline-none transition focus:border-sky-500 focus:bg-white focus:ring-4 focus:ring-sky-100"
              />
            </div>

            <button
              type="submit"
              disabled={!codeInput.trim()}
              className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-sky-600 px-5 py-3 text-sm font-semibold text-white transition hover:bg-sky-700 disabled:cursor-not-allowed disabled:opacity-50"
            >
              Verify Certificate
            </button>
          </form>

          <p className="mt-6 text-center text-xs text-slate-400">
            The verification code is printed on every certificate issued by
            QNAYDS Academy.
          </p>
        </div>
      </div>
    );
  }

  // ==========================
  // LOADING
  // ==========================

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-50 px-6">
        <div className="flex flex-col items-center gap-4 text-center">
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-sky-50">
            <Loader2 className="h-8 w-8 animate-spin text-sky-600" />
          </div>

          <div>
            <h2 className="text-lg font-semibold text-slate-900">
              Verifying Certificate
            </h2>

            <p className="mt-1 text-sm text-slate-500">
              Please wait while we verify the certificate.
            </p>
          </div>
        </div>
      </div>
    );
  }

  // ==========================
  // INVALID
  // ==========================

  if (!checked || !valid || !certificate) {
    return (
      <div className="min-h-screen bg-slate-50 px-4 py-10 md:px-8">
        <div className="mx-auto flex min-h-[80vh] max-w-2xl items-center justify-center">
          <div className="w-full rounded-3xl border border-slate-200 bg-white p-8 text-center shadow-sm md:p-12">
            <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-red-50">
              <XCircle className="h-10 w-10 text-red-500" />
            </div>

            <p className="mt-6 text-xs font-semibold uppercase tracking-[0.25em] text-slate-400">
              QNAYDS ACADEMY
            </p>

            <h1 className="mt-3 text-2xl font-bold text-slate-900 md:text-3xl">
              Certificate Not Verified
            </h1>

            <p className="mx-auto mt-3 max-w-md text-sm leading-6 text-slate-500">
              {error ||
                "The certificate verification code is invalid or the certificate could not be found."}
            </p>

            <div className="mx-auto mt-6 max-w-md rounded-xl border border-red-100 bg-red-50 px-4 py-3 text-left">
              <p className="text-xs font-medium text-red-600">
                Verification Code
              </p>

              <p className="mt-1 break-all text-xs text-red-500">
                {verificationCode || "Not provided"}
              </p>
            </div>

            <div className="mt-7 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <Link
                to="/verify-certificate"
                className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-5 py-2.5 text-sm font-semibold text-slate-600 transition hover:border-sky-200 hover:text-sky-600"
              >
                Try another code
              </Link>

              <Link
                to="/"
                className="inline-flex items-center gap-2 rounded-xl bg-sky-600 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-sky-700"
              >
                Back to QNAYDS
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ==========================
  // VALID
  // ==========================

  const typeMeta = getTypeMeta(certificate.type);
  const TypeIcon = typeMeta.icon;

  return (
    <div className="min-h-screen bg-slate-50 px-4 py-8 md:px-8 md:py-12">
      <div className="mx-auto max-w-4xl">
        {/* Header */}

        <div className="text-center">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-sky-50">
            <Award className="h-8 w-8 text-sky-600" />
          </div>

          <p className="mt-5 text-xs font-semibold uppercase tracking-[0.3em] text-sky-600">
            QNAYDS ACADEMY
          </p>

          <h1 className="mt-3 text-3xl font-bold tracking-tight text-slate-900 md:text-4xl">
            Certificate Verification
          </h1>

          <p className="mx-auto mt-3 max-w-xl text-sm leading-6 text-slate-500">
            Verify the authenticity of a certificate issued by QNAYDS Academy.
          </p>
        </div>

        {/* Valid Card */}

        <div className="mt-8 overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-xl shadow-slate-200/50">
          {/* Success Header */}

          <div className="border-b border-emerald-100 bg-emerald-50 px-6 py-5 md:px-8">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-white shadow-sm">
                <CheckCircle2 className="h-7 w-7 text-emerald-500" />
              </div>

              <div>
                <h2 className="text-lg font-bold text-emerald-800">
                  Certificate Verified
                </h2>

                <p className="mt-0.5 text-sm text-emerald-700">
                  This certificate is valid and was issued by QNAYDS Academy.
                </p>
              </div>
            </div>
          </div>

          {/* Certificate Content */}

          <div className="p-6 md:p-10">
            {/* Student */}

            <div className="rounded-2xl border border-slate-200 bg-slate-50 p-6 text-center">
              <p className="text-xs font-semibold uppercase tracking-[0.2em] text-slate-400">
                Certificate Awarded To
              </p>

              <h2 className="mt-3 text-3xl font-bold text-slate-900 md:text-4xl">
                {certificate.studentName}
              </h2>
            </div>

            {/* Course / Program + Type */}

            <div className="mt-6 rounded-2xl border border-slate-200 p-6">
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-start gap-4 min-w-0">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-sky-50">
                    <Award className="h-5 w-5 text-sky-600" />
                  </div>

                  <div className="min-w-0">
                    <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                      {typeMeta.label} Completed
                    </p>

                    <h3 className="mt-2 text-xl font-semibold text-slate-900 md:text-2xl">
                      {certificate.programName}
                    </h3>
                  </div>
                </div>

                <span className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-sky-200 bg-sky-50 px-3 py-1.5 text-xs font-medium text-sky-700">
                  <TypeIcon className="h-3.5 w-3.5" />
                  {typeMeta.label}
                </span>
              </div>
            </div>

            {/* Details */}

            <div className="mt-6 grid gap-4 md:grid-cols-2">
              <div className="rounded-2xl border border-slate-200 p-5">
                <div className="flex items-center gap-3">
                  <CalendarDays className="h-5 w-5 text-slate-400" />

                  <div>
                    <p className="text-xs font-medium uppercase tracking-wider text-slate-400">
                      Issue Date
                    </p>

                    <p className="mt-1 text-sm font-semibold text-slate-900">
                      {formatDate(certificate.issuedAt)}
                    </p>
                  </div>
                </div>
              </div>

              <div className="rounded-2xl border border-slate-200 p-5">
                <div className="flex items-center gap-3">
                  <ShieldCheck className="h-5 w-5 text-emerald-500" />

                  <div className="min-w-0">
                    <p className="text-xs font-medium uppercase tracking-wider text-slate-400">
                      Certificate Number
                    </p>

                    <p className="mt-1 break-all text-sm font-semibold text-slate-900">
                      {certificate.certificateNumber}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Verification Code */}

            <div className="mt-6 rounded-2xl border border-slate-200 bg-slate-50 p-5">
              <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                Verification Code
              </p>

              <p className="mt-2 break-all font-mono text-xs text-slate-600">
                {verificationCode}
              </p>
            </div>

            {/* Footer */}

            <div className="mt-8 flex flex-col items-center justify-between gap-4 border-t border-slate-100 pt-6 sm:flex-row">
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <ShieldCheck className="h-4 w-4 text-emerald-500" />
                Digitally verified by QNAYDS Academy
              </div>

              <div className="flex items-center gap-3">
                <Link
                  to="/verify-certificate"
                  className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-medium text-slate-600 transition hover:border-sky-200 hover:text-sky-600"
                >
                  Verify another
                </Link>

                <Link
                  to="/"
                  className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-medium text-slate-600 transition hover:border-sky-200 hover:text-sky-600"
                >
                  Visit QNAYDS
                </Link>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom note */}

        <p className="mt-6 text-center text-xs text-slate-400">
          If you believe this certificate has been issued incorrectly, please
          contact QNAYDS Academy.
        </p>
      </div>
    </div>
  );
};

export default CertificateVerification;