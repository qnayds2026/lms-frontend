import { useEffect, useState, useRef } from "react";
import { useParams, Link } from "react-router-dom";
import {
  ChevronLeft,
  ChevronDown,
  Plus,
  Eye,
  EyeOff,
  Terminal,
  PlaySquare,
  X,
  Pencil,
  Trash2,
  GripVertical,
  Layers,
  NotebookText,
} from "lucide-react";
import api from "../../api/axios";
import ModuleNotes from "../../components/notes/ModuleNotes";

const FONT_IMPORT = `@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap');`;

const display = { fontFamily: "'Space Grotesk', sans-serif" };
const mono = { fontFamily: "'JetBrains Mono', monospace" };

function AddRecordingModal({ moduleId, onClose, onCreated }) {
  const [form, setForm] = useState({
    title: "",
    description: "",
    youtubeUrl: "",
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSaving(true);
    try {
      const res = await api.post("/recordings", {
        title: form.title,
        description: form.description,
        videoUrl: form.youtubeUrl,
        moduleId,
      });
      onCreated(res.data);
      onClose();
    } catch (err) {
      setError(err?.response?.data?.error || "Failed to add recording.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/40 flex items-center justify-center z-50 px-4">
      <div className="bg-white rounded-2xl w-full max-w-md p-6 relative">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 text-slate-400 hover:text-slate-600"
        >
          <X className="w-5 h-5" />
        </button>
        <h3 className="text-lg font-semibold text-slate-900" style={display}>
          Add Recording
        </h3>
        {error && (
          <div className="mt-3 rounded-lg bg-red-50 border border-red-200 px-3 py-2 text-sm text-red-600">
            {error}
          </div>
        )}
        <form onSubmit={handleSubmit} className="mt-4 space-y-3">
          <input
            required
            placeholder="Lesson title"
            value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100"
          />
          <textarea
            placeholder="Description (optional)"
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100"
            rows={3}
          />
          <input
            required
            placeholder="YouTube or Google Drive URL"
            value={form.youtubeUrl}
            onChange={(e) => setForm({ ...form, youtubeUrl: e.target.value })}
            className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100"
          />
          <p className="text-xs text-slate-400 -mt-1">
            Paste a YouTube link, or a Google Drive share link (make sure
            sharing is set to "Anyone with the link").
          </p>
          <button
            type="submit"
            disabled={saving}
            className="w-full bg-sky-600 hover:bg-sky-700 disabled:opacity-60 text-white py-2.5 rounded-lg font-medium text-sm transition"
          >
            {saving ? "Saving..." : "Add Recording"}
          </button>
        </form>
      </div>
    </div>
  );
}

function EditRecordingModal({ recording, onClose, onUpdated }) {
  const [form, setForm] = useState({
    title: recording.title || "",
    description: recording.description || "",
    youtubeUrl:
      recording.videoUrl ||
      (recording.videoId
        ? `https://www.youtube.com/watch?v=${recording.videoId}`
        : ""),
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSaving(true);
    try {
      const res = await api.patch(`/recordings/${recording.id}`, {
        title: form.title,
        description: form.description,
        videoUrl: form.youtubeUrl,
      });
      onUpdated(res.data);
      onClose();
    } catch (err) {
      setError(err?.response?.data?.error || "Failed to update recording.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/40 flex items-center justify-center z-50 px-4">
      <div className="bg-white rounded-2xl w-full max-w-md p-6 relative">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 text-slate-400 hover:text-slate-600"
        >
          <X className="w-5 h-5" />
        </button>
        <h3 className="text-lg font-semibold text-slate-900" style={display}>
          Edit Recording
        </h3>
        {error && (
          <div className="mt-3 rounded-lg bg-red-50 border border-red-200 px-3 py-2 text-sm text-red-600">
            {error}
          </div>
        )}
        <form onSubmit={handleSubmit} className="mt-4 space-y-3">
          <input
            required
            placeholder="Lesson title"
            value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100"
          />
          <textarea
            placeholder="Description (optional)"
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100"
            rows={3}
          />
          <input
            required
            placeholder="YouTube or Google Drive URL"
            value={form.youtubeUrl}
            onChange={(e) => setForm({ ...form, youtubeUrl: e.target.value })}
            className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100"
          />
          <p className="text-xs text-slate-400 -mt-1">
            Paste a YouTube link, or a Google Drive share link (make sure
            sharing is set to "Anyone with the link").
          </p>
          <button
            type="submit"
            disabled={saving}
            className="w-full bg-sky-600 hover:bg-sky-700 disabled:opacity-60 text-white py-2.5 rounded-lg font-medium text-sm transition"
          >
            {saving ? "Saving..." : "Save Changes"}
          </button>
        </form>
      </div>
    </div>
  );
}

function VideoPreviewModal({ recording, onClose }) {
  const embedSrc =
    recording.embedUrl ||
    (recording.videoId
      ? `https://www.youtube.com/embed/${recording.videoId}`
      : null);

  return (
    <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center z-50 px-4">
      <div className="bg-white rounded-2xl w-full max-w-2xl overflow-hidden relative">
        <div className="flex items-center justify-between px-5 py-3 border-b border-slate-100">
          <h3
            className="text-sm font-semibold text-slate-900 truncate pr-4"
            style={display}
          >
            {recording.title}
          </h3>
          <button
            onClick={onClose}
            className="shrink-0 text-slate-400 hover:text-slate-600"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="aspect-video bg-black">
          {embedSrc ? (
            <iframe
              src={embedSrc}
              title={recording.title}
              className="w-full h-full"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center gap-3 text-slate-400 text-sm px-6 text-center">
              <p>Couldn&apos;t build an embeddable preview for this link.</p>
              {recording.videoUrl && (
                <a
                  href={recording.videoUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="text-sky-400 hover:text-sky-300 underline"
                >
                  Open the original link instead
                </a>
              )}
            </div>
          )}
        </div>
        {recording.description && (
          <p className="px-5 py-3 text-sm text-slate-500 border-t border-slate-100">
            {recording.description}
          </p>
        )}
      </div>
    </div>
  );
}

function AddModuleModal({ courseId, onClose, onCreated }) {
  const [title, setTitle] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSaving(true);
    try {
      const res = await api.post("/modules", { title, courseId });
      onCreated(res.data);
      onClose();
    } catch (err) {
      setError(
        err?.response?.data?.error ||
          err?.response?.data?.message ||
          "Failed to add module.",
      );
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/40 flex items-center justify-center z-50 px-4">
      <div className="bg-white rounded-2xl w-full max-w-md p-6 relative">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 text-slate-400 hover:text-slate-600"
        >
          <X className="w-5 h-5" />
        </button>
        <h3 className="text-lg font-semibold text-slate-900" style={display}>
          Add Module
        </h3>
        {error && (
          <div className="mt-3 rounded-lg bg-red-50 border border-red-200 px-3 py-2 text-sm text-red-600">
            {error}
          </div>
        )}
        <form onSubmit={handleSubmit} className="mt-4 space-y-3">
          <input
            required
            autoFocus
            placeholder="Module title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100"
          />
          <button
            type="submit"
            disabled={saving}
            className="w-full bg-sky-600 hover:bg-sky-700 disabled:opacity-60 text-white py-2.5 rounded-lg font-medium text-sm transition"
          >
            {saving ? "Saving..." : "Add Module"}
          </button>
        </form>
      </div>
    </div>
  );
}

function EditModuleModal({ module, onClose, onUpdated }) {
  const [title, setTitle] = useState(module.title || "");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSaving(true);
    try {
      const res = await api.put(`/modules/${module.id}`, { title });
      onUpdated(res.data);
      onClose();
    } catch (err) {
      setError(
        err?.response?.data?.error ||
          err?.response?.data?.message ||
          "Failed to update module.",
      );
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/40 flex items-center justify-center z-50 px-4">
      <div className="bg-white rounded-2xl w-full max-w-md p-6 relative">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 text-slate-400 hover:text-slate-600"
        >
          <X className="w-5 h-5" />
        </button>
        <h3 className="text-lg font-semibold text-slate-900" style={display}>
          Edit Module
        </h3>
        {error && (
          <div className="mt-3 rounded-lg bg-red-50 border border-red-200 px-3 py-2 text-sm text-red-600">
            {error}
          </div>
        )}
        <form onSubmit={handleSubmit} className="mt-4 space-y-3">
          <input
            required
            autoFocus
            placeholder="Module title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100"
          />
          <button
            type="submit"
            disabled={saving}
            className="w-full bg-sky-600 hover:bg-sky-700 disabled:opacity-60 text-white py-2.5 rounded-lg font-medium text-sm transition"
          >
            {saving ? "Saving..." : "Save Changes"}
          </button>
        </form>
      </div>
    </div>
  );
}

const AdminManageRecordings = () => {
  const { courseId } = useParams();
  const [course, setCourse] = useState(null);
  const [modules, setModules] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [modalModuleId, setModalModuleId] = useState(null);
  const [editingRecording, setEditingRecording] = useState(null);
  const [previewRecording, setPreviewRecording] = useState(null);
  const [deletingId, setDeletingId] = useState(null);

  const [addModuleOpen, setAddModuleOpen] = useState(false);
  const [editingModule, setEditingModule] = useState(null);
  const [deletingModuleId, setDeletingModuleId] = useState(null);

  // Which modules currently have their Notes panel expanded
  const [openNotes, setOpenNotes] = useState(new Set());
  const toggleNotes = (moduleId) => {
    setOpenNotes((prev) => {
      const next = new Set(prev);
      if (next.has(moduleId)) {
        next.delete(moduleId);
      } else {
        next.add(moduleId);
      }
      return next;
    });
  };

  // Note count per module, filled in as soon as each module's ModuleNotes
  // instance mounts (it's always mounted, just visually hidden when
  // collapsed — see render below), so counts are accurate immediately.
  const [noteCounts, setNoteCounts] = useState({});

  // Refs into each module's ModuleNotes instance, so the header's quick-add
  // button can open the note form directly without requiring the panel to
  // be expanded first.
  const moduleNotesRefs = useRef({});

  const dragModuleId = useRef(null);
  const dragIndex = useRef(null);
  const [dragOverIndex, setDragOverIndex] = useState({
    moduleId: null,
    index: null,
  });
  const [reordering, setReordering] = useState(null);

  const dragModuleIndex = useRef(null);
  const [dragOverModuleIndex, setDragOverModuleIndex] = useState(null);
  const [reorderingModules, setReorderingModules] = useState(false);

  const fetchData = async () => {
    setLoading(true);
    setError("");
    try {
      const courseRes = await api.get(`/courses/${courseId}`);
      setCourse(courseRes.data);

      const moduleList = courseRes.data?.modules || [];

      const recordingsByModule = await Promise.all(
        moduleList.map((m) =>
          api
            .get(`/recordings/module/${m.id}`)
            .then((res) => res.data)
            .catch(() => []),
        ),
      );

      setModules(
        moduleList.map((m, i) => ({
          id: m.id,
          title: m.title,
          recordings: recordingsByModule[i] || [],
        })),
      );
    } catch (err) {
      setError(err?.response?.data?.message || "Failed to load course.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [courseId]);

  const togglePublish = async (recording, moduleId) => {
    try {
      const endpoint = recording.isPublished
        ? `/recordings/${recording.id}/unpublish`
        : `/recordings/${recording.id}/publish`;
      await api.patch(endpoint);
      setModules((prev) =>
        prev.map((m) =>
          m.id === moduleId
            ? {
                ...m,
                recordings: m.recordings.map((r) =>
                  r.id === recording.id
                    ? { ...r, isPublished: !r.isPublished }
                    : r,
                ),
              }
            : m,
        ),
      );
    } catch (err) {
      alert(err?.response?.data?.error || "Failed to update publish status.");
    }
  };

  const handleUpdated = (moduleId, updated) => {
    setModules((prev) =>
      prev.map((m) =>
        m.id === moduleId
          ? {
              ...m,
              recordings: m.recordings.map((r) =>
                r.id === updated.id ? { ...r, ...updated } : r,
              ),
            }
          : m,
      ),
    );
  };

  const handleDelete = async (recording, moduleId) => {
    if (!window.confirm(`Delete "${recording.title}"? This can't be undone.`)) {
      return;
    }
    setDeletingId(recording.id);
    try {
      await api.delete(`/recordings/${recording.id}`);
      setModules((prev) =>
        prev.map((m) =>
          m.id === moduleId
            ? {
                ...m,
                recordings: m.recordings.filter((r) => r.id !== recording.id),
              }
            : m,
        ),
      );
    } catch (err) {
      alert(err?.response?.data?.error || "Failed to delete recording.");
    } finally {
      setDeletingId(null);
    }
  };

  const handleModuleCreated = (newModule) => {
    setModules((prev) => [
      ...prev,
      { id: newModule.id, title: newModule.title, recordings: [] },
    ]);
  };

  const handleModuleUpdated = (updated) => {
    setModules((prev) =>
      prev.map((m) =>
        m.id === updated.id ? { ...m, title: updated.title } : m,
      ),
    );
  };

  const handleDeleteModule = async (module) => {
    const recordingCount = module.recordings.length;
    const warning =
      recordingCount > 0
        ? `Delete "${module.title}"? This will also delete ${recordingCount} recording${
            recordingCount === 1 ? "" : "s"
          } inside it. This can't be undone.`
        : `Delete "${module.title}"? This can't be undone.`;

    if (!window.confirm(warning)) return;

    setDeletingModuleId(module.id);
    try {
      await api.delete(`/modules/${module.id}`);
      setModules((prev) => prev.filter((m) => m.id !== module.id));
    } catch (err) {
      alert(
        err?.response?.data?.error ||
          err?.response?.data?.message ||
          "Failed to delete module.",
      );
    } finally {
      setDeletingModuleId(null);
    }
  };

  const persistOrder = async (moduleId, orderedRecordings) => {
    setReordering(moduleId);
    try {
      await api.patch("/recordings/reorder", {
        moduleId,
        orderedIds: orderedRecordings.map((r) => r.id),
      });
    } catch (err) {
      alert(
        err?.response?.data?.error ||
          "Failed to save new order. Refresh and try again.",
      );
      fetchData();
    } finally {
      setReordering(null);
    }
  };

  const handleDragStart = (moduleId, index) => {
    dragModuleId.current = moduleId;
    dragIndex.current = index;
  };

  const handleDragOver = (e, moduleId, index) => {
    e.preventDefault();
    if (dragModuleId.current !== moduleId) return;
    setDragOverIndex({ moduleId, index });
  };

  const handleDrop = (e, moduleId, dropIndex) => {
    e.preventDefault();
    const fromModuleId = dragModuleId.current;
    const fromIndex = dragIndex.current;
    setDragOverIndex({ moduleId: null, index: null });
    dragModuleId.current = null;
    dragIndex.current = null;

    if (
      fromModuleId !== moduleId ||
      fromIndex === null ||
      fromIndex === dropIndex
    ) {
      return;
    }

    setModules((prev) =>
      prev.map((m) => {
        if (m.id !== moduleId) return m;
        const updated = [...m.recordings];
        const [moved] = updated.splice(fromIndex, 1);
        updated.splice(dropIndex, 0, moved);
        persistOrder(moduleId, updated);
        return { ...m, recordings: updated };
      }),
    );
  };

  const handleDragEnd = () => {
    dragModuleId.current = null;
    dragIndex.current = null;
    setDragOverIndex({ moduleId: null, index: null });
  };

  const persistModuleOrder = async (orderedModules) => {
    setReorderingModules(true);
    try {
      await api.patch("/modules/reorder", {
        courseId,
        orderedIds: orderedModules.map((m) => m.id),
      });
    } catch (err) {
      alert(
        err?.response?.data?.message ||
          err?.response?.data?.error ||
          "Failed to save new module order. Refresh and try again.",
      );
      fetchData();
    } finally {
      setReorderingModules(false);
    }
  };

  const handleModuleDragStart = (index) => {
    dragModuleIndex.current = index;
  };

  const handleModuleDragOver = (e, index) => {
    e.preventDefault();
    setDragOverModuleIndex(index);
  };

  const handleModuleDrop = (e, dropIndex) => {
    e.preventDefault();
    const fromIndex = dragModuleIndex.current;
    dragModuleIndex.current = null;
    setDragOverModuleIndex(null);

    if (fromIndex === null || fromIndex === dropIndex) return;

    setModules((prev) => {
      const updated = [...prev];
      const [moved] = updated.splice(fromIndex, 1);
      updated.splice(dropIndex, 0, moved);
      persistModuleOrder(updated);
      return updated;
    });
  };

  const handleModuleDragEnd = () => {
    dragModuleIndex.current = null;
    setDragOverModuleIndex(null);
  };

  if (loading) {
    return (
      <div className="p-6 md:p-10 bg-slate-50 min-h-screen animate-pulse">
        <div className="h-8 w-64 bg-slate-200 rounded-lg" />
        <div className="mt-8 space-y-4">
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              className="bg-white rounded-2xl border border-slate-200 h-24"
            />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 md:p-10 bg-slate-50 min-h-screen">
      <style>{FONT_IMPORT}</style>

      <Link
        to="/admin/courses"
        className="inline-flex items-center gap-1 text-sm font-medium text-slate-500 hover:text-sky-600 transition-colors mb-4"
      >
        <ChevronLeft className="h-4 w-4" />
        Back to Courses
      </Link>

      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <span
            className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full border border-sky-200 bg-sky-50 text-sky-700 text-xs font-medium"
            style={mono}
          >
            <Terminal className="w-3.5 h-3.5" /> manage_recordings
          </span>
          <h1
            className="mt-3 text-2xl font-semibold text-slate-900"
            style={display}
          >
            {course?.title}
          </h1>
        </div>

        <div className="flex items-center gap-3">
          {reorderingModules && (
            <span className="text-xs text-slate-400" style={mono}>
              saving module order...
            </span>
          )}
          <button
            onClick={() => setAddModuleOpen(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-sky-600 text-white text-sm font-medium hover:bg-sky-700 transition-colors"
          >
            <Layers className="h-4 w-4" />
            Add Module
          </button>
        </div>
      </div>

      {error && (
        <div className="mt-6 rounded-xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-600">
          {error}
        </div>
      )}

      <div className="mt-8 space-y-6">
        {modules.map((module, moduleIndex) => {
          const notesOpen = openNotes.has(module.id);
          return (
            <div
              key={module.id}
              draggable
              onDragStart={() => handleModuleDragStart(moduleIndex)}
              onDragOver={(e) => handleModuleDragOver(e, moduleIndex)}
              onDrop={(e) => handleModuleDrop(e, moduleIndex)}
              onDragEnd={handleModuleDragEnd}
              className={`bg-white rounded-2xl border border-slate-200 transition-colors ${
                dragOverModuleIndex === moduleIndex
                  ? "border-sky-300 bg-sky-50/40"
                  : ""
              }`}
            >
              {/* Module header */}
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 px-4 sm:px-5 py-4 bg-sky-50/70 border-b border-sky-100 border-l-[3px] border-l-sky-500 rounded-t-2xl">
                <div className="flex items-center gap-2 flex-wrap min-w-0">
                  <span
                    className="shrink-0 cursor-grab active:cursor-grabbing text-sky-300 hover:text-sky-500"
                    title="Drag to reorder module"
                  >
                    <GripVertical className="h-4 w-4" />
                  </span>
                  <Layers className="h-3.5 w-3.5 text-sky-500 shrink-0" />
                  <h2
                    className="text-xs font-semibold text-sky-700 uppercase tracking-wide wrap-break-words"
                    style={mono}
                  >
                    {module.title}
                  </h2>
                  <button
                    onClick={() => setEditingModule(module)}
                    className="inline-flex items-center justify-center h-6 w-6 rounded-md text-sky-400 hover:text-sky-700 hover:bg-sky-100 transition-colors shrink-0"
                    title="Edit module"
                  >
                    <Pencil className="h-3.5 w-3.5" />
                  </button>
                  <button
                    onClick={() => handleDeleteModule(module)}
                    disabled={deletingModuleId === module.id}
                    className="inline-flex items-center justify-center h-6 w-6 rounded-md text-sky-400 hover:text-red-600 hover:bg-red-50 transition-colors disabled:opacity-50 shrink-0"
                    title="Delete module"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                  {reordering === module.id && (
                    <span className="text-xs text-sky-400" style={mono}>
                      saving order...
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2 flex-wrap shrink-0">
                  {/* Notes — context-aware: opens the add form directly when the
                      module has no notes yet, otherwise toggles the panel.
                      This removes the need for a second, confusing "+" button. */}
                  <button
                    onClick={() => {
                      if (notesOpen) {
                        toggleNotes(module.id);
                      } else {
                        const count = noteCounts[module.id];
                        if (count === 0) {
                          setOpenNotes((prev) => new Set(prev).add(module.id));
                          moduleNotesRefs.current[module.id]?.openAdd();
                        } else {
                          toggleNotes(module.id);
                        }
                      }
                    }}
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
                      notesOpen
                        ? "bg-sky-600 text-white"
                        : "bg-white text-sky-700 border border-sky-200 hover:bg-sky-50"
                    }`}
                  >
                    <NotebookText className="h-3.5 w-3.5" />
                    Notes
                    {noteCounts[module.id] !== undefined && (
                      <span
                        className={`inline-flex items-center justify-center min-w-[1.1rem] h-[1.1rem] px-1 rounded-full text-[10px] ${
                          notesOpen
                            ? "bg-white/25 text-white"
                            : noteCounts[module.id] === 0
                              ? "bg-amber-100 text-amber-700"
                              : "bg-sky-100 text-sky-700"
                        }`}
                      >
                        {noteCounts[module.id]}
                      </span>
                    )}
                    {notesOpen ? (
                      <ChevronDown className="h-3.5 w-3.5 rotate-180 transition-transform" />
                    ) : noteCounts[module.id] === 0 ? (
                      <Plus className="h-3.5 w-3.5" />
                    ) : (
                      <ChevronDown className="h-3.5 w-3.5 transition-transform" />
                    )}
                  </button>

                  <button
                    onClick={() => setModalModuleId(module.id)}
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-sky-600 hover:text-sky-700 whitespace-nowrap"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    Add Recording
                  </button>
                </div>
              </div>

              {/* Recordings list */}
              <ul className="divide-y divide-slate-100">
                {module.recordings.map((rec, index) => (
                  <li
                    key={rec.id}
                    draggable
                    onDragStart={() => handleDragStart(module.id, index)}
                    onDragOver={(e) => handleDragOver(e, module.id, index)}
                    onDrop={(e) => handleDrop(e, module.id, index)}
                    onDragEnd={handleDragEnd}
                    className={`flex items-center gap-2 sm:gap-3 px-4 sm:px-5 py-3 flex-wrap sm:flex-nowrap transition-colors ${
                      dragOverIndex.moduleId === module.id &&
                      dragOverIndex.index === index
                        ? "bg-sky-50"
                        : ""
                    }`}
                  >
                    <span
                      className="hidden sm:block shrink-0 cursor-grab active:cursor-grabbing text-slate-300 hover:text-slate-500"
                      title="Drag to reorder"
                    >
                      <GripVertical className="h-4 w-4" />
                    </span>
                    <button
                      onClick={() => setPreviewRecording(rec)}
                      className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-sky-50 hover:bg-sky-100 transition-colors"
                      title="Preview video"
                    >
                      <PlaySquare className="h-4 w-4 text-sky-600" />
                    </button>
                    <button
                      onClick={() => setPreviewRecording(rec)}
                      className="flex-1 min-w-30 text-left"
                      title="Preview video"
                    >
                      <p className="text-sm font-medium text-slate-900 truncate hover:text-sky-600 transition-colors">
                        {rec.title}
                      </p>
                      {rec.duration && (
                        <p className="text-xs text-slate-400">{rec.duration}</p>
                      )}
                    </button>
                    <button
                      onClick={() => togglePublish(rec, module.id)}
                      className={`shrink-0 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                        rec.isPublished
                          ? "bg-emerald-50 text-emerald-600 hover:bg-emerald-100"
                          : "bg-slate-100 text-slate-500 hover:bg-slate-200"
                      }`}
                    >
                      {rec.isPublished ? (
                        <Eye className="h-3.5 w-3.5" />
                      ) : (
                        <EyeOff className="h-3.5 w-3.5" />
                      )}
                      {rec.isPublished ? "Published" : "Draft"}
                    </button>
                    <div className="flex items-center gap-1 shrink-0 ml-auto sm:ml-0">
                      <button
                        onClick={() =>
                          setEditingRecording({
                            moduleId: module.id,
                            recording: rec,
                          })
                        }
                        className="shrink-0 inline-flex items-center justify-center h-8 w-8 rounded-lg text-slate-400 hover:text-sky-600 hover:bg-sky-50 transition-colors"
                        title="Edit recording"
                      >
                        <Pencil className="h-3.5 w-3.5" />
                      </button>
                      <button
                        onClick={() => handleDelete(rec, module.id)}
                        disabled={deletingId === rec.id}
                        className="shrink-0 inline-flex items-center justify-center h-8 w-8 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 transition-colors disabled:opacity-50"
                        title="Delete recording"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </li>
                ))}
                {module.recordings.length === 0 && (
                  <li className="px-5 py-6 text-center text-sm text-slate-400">
                    No recordings yet.
                  </li>
                )}
              </ul>

              {/* Notes panel — always mounted (so counts load immediately and the
                  quick-add ref is always ready), just visually hidden when collapsed */}
              <div
                className={`border-t border-slate-100 px-5 pb-5 ${
                  notesOpen ? "" : "hidden"
                }`}
              >
                <ModuleNotes
                  ref={(el) => {
                    moduleNotesRefs.current[module.id] = el;
                  }}
                  moduleId={module.id}
                  editable
                  onClose={() => toggleNotes(module.id)}
                  onCountChange={(count) =>
                    setNoteCounts((prev) => ({ ...prev, [module.id]: count }))
                  }
                />
              </div>
            </div>
          );
        })}

        {modules.length === 0 && (
          <div className="bg-white rounded-2xl border border-dashed border-slate-200 p-10 text-center text-sm text-slate-400">
            This course has no modules yet.
          </div>
        )}
      </div>

      {modalModuleId && (
        <AddRecordingModal
          moduleId={modalModuleId}
          onClose={() => setModalModuleId(null)}
          onCreated={(newRec) =>
            setModules((prev) =>
              prev.map((m) =>
                m.id === modalModuleId
                  ? { ...m, recordings: [...m.recordings, newRec] }
                  : m,
              ),
            )
          }
        />
      )}

      {editingRecording && (
        <EditRecordingModal
          recording={editingRecording.recording}
          onClose={() => setEditingRecording(null)}
          onUpdated={(updated) =>
            handleUpdated(editingRecording.moduleId, updated)
          }
        />
      )}

      {previewRecording && (
        <VideoPreviewModal
          recording={previewRecording}
          onClose={() => setPreviewRecording(null)}
        />
      )}

      {addModuleOpen && (
        <AddModuleModal
          courseId={courseId}
          onClose={() => setAddModuleOpen(false)}
          onCreated={handleModuleCreated}
        />
      )}

      {editingModule && (
        <EditModuleModal
          module={editingModule}
          onClose={() => setEditingModule(null)}
          onUpdated={handleModuleUpdated}
        />
      )}
    </div>
  );
};

export default AdminManageRecordings;
